// Draft only. No signing keys, uploads, deployment hooks, or writable HTTP routes.
export default {
 async fetch(request,env){
  const headers=new Headers({'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'});
  if(env.PUBLISH_ENABLED!=='true')return new Response('Not published',{status:503,headers});
  if(!['GET','HEAD'].includes(request.method)){headers.set('Allow','GET, HEAD');return new Response(null,{status:405,headers})}
  const url=new URL(request.url);let key,metadata=false;
  if(url.search||url.pathname.includes('%'))return new Response(null,{status:404,headers});
  if(url.pathname==='/stable/latest.json'){key='stable/latest.json';metadata=true}
  else {const match=/^\/releases\/(\d{1,4}\.\d{1,4}\.\d{1,4})\/Reqoo-3D-Studio-(\d{1,4}\.\d{1,4}\.\d{1,4})-(Setup-x64\.exe|Portable-x64\.zip)$/.exec(url.pathname);if(!match||match[1]!==match[2])return new Response(null,{status:404,headers});key=url.pathname.slice(1)}
  if(request.headers.has('Range'))return new Response(null,{status:416,headers});
  try{
   const object=await (request.method==='HEAD'?env.RELEASES.head(key):env.RELEASES.get(key));
   if(!object)return new Response(null,{status:404,headers});
   if(!Number.isSafeInteger(object.size)||object.size<1||object.size>(metadata?131072:524288000))return new Response(null,{status:503,headers});
   headers.set('Content-Type',metadata?'application/json; charset=utf-8':'application/octet-stream');headers.set('Content-Length',String(object.size));headers.set('ETag',object.httpEtag);
   if(!metadata){headers.set('Cache-Control','public, max-age=31536000, immutable');headers.set('Content-Disposition','attachment; filename="'+key.split('/').at(-1)+'"')}
   return new Response(request.method==='HEAD'?null:object.body,{status:200,headers});
  }catch{console.error(JSON.stringify({event:'release_read_failed',metadata}));return new Response('Unavailable',{status:503,headers})}
 }
};
