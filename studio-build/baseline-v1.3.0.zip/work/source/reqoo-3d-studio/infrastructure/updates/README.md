# Update service draft — NOT DEPLOYED

This directory is excluded from the Windows app package. `worker.mjs` serves only signed release metadata and versioned installer/portable files through an R2 binding. It cannot sign metadata, accept uploads or expose source/private keys. Publication is disabled in `wrangler.jsonc`.

Node contract tests: `node --test tests/update-worker-draft.test.js`. Cloudflare runtime, generated binding types, Wrangler schema/dry-run and end-to-end deployment still require validation after owner approval. Account IDs, real routes and endpoint URLs are intentionally absent. Do not deploy or upload without the owner's explicit approval.

Before production, follow current Cloudflare Workers best practices and R2 binding documentation; generate Env types with the selected Wrangler version. Keep the release private signing key on the owner PC. Publish artifacts before signed latest metadata, and preserve old versioned files for manual recovery. No automatic installer execution is part of this subphase.
